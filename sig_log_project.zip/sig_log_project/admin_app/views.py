from django.shortcuts import redirect, render
from django.contrib.auth import authenticate,login,logout 
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from user_app.models import Custom_User
from . forms import Admin_User_form
from . models import LogUser

# Create your views here.

def home(request):
    users = Custom_User.objects.all()
    log_user_info = LogUser.objects.all()

    return render(request,'admin_app/home.html',{'users':users,'log_users_info':log_user_info})


def admin_login(request):

    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request,username = username ,password = password)

        if user and user.is_superuser:
            login(request,user)
            return redirect('admin_app:admin_home')
        elif user is None:

            try :
                user = Custom_User.objects.get(username = username)
                
                password_matched =user.check_password(password)
                    

                if password_matched:

                    if  user.is_super_user:

                        request.user=user
                        return redirect('admin_app:admin_home')
                    else:
                        messages.info(request,"You don't have permissions")

                else:
                    messages.info(request,'Invalid credentials')

            except ObjectDoesNotExist:
                    messages.error(request,"Admin doesn't exist")

        

    return render(request,'admin_app/admin_login.html')


def admin_logout(request):
    logout(request)
    return redirect('admin_app:admin_home')


def admin_create_user(request):
    if request.method == 'POST':
        form = Admin_User_form(request.POST,request.FILES)
        if form.is_valid():
            user = form.save(commit=False)
           #we want to hash the password before saving it into the db
           
           # user.password=make_password(form.cleaned_data['password'])
            user.password= user.make_password(form.cleaned_data['password'])

            user.save()
            return redirect('admin_app:admin_home')
        else:
            
            
            return render(request,"user_app/user_creation.html",{'form': form})
    form = Admin_User_form()
    
    return render(request,"user_app/user_creation.html",{'form': form})



def admin_update_user(request,id):

    user_instance = Custom_User.objects.get(id=id)

    if request.method == 'POST':
        form = Admin_User_form(request.POST,request.FILES,instance = user_instance)
        if form.is_valid():
            form.save()
            return redirect('admin_app:admin_home')
        else:
            
            
            return render(request,"user_app/user_creation.html",{'form': form})
        
    form = Admin_User_form(instance=user_instance)
    
    return render(request,"user_app/user_creation.html",{'form': form})
    



def admin_delete_user(reqest,id):
    
        user= Custom_User.objects.get(id=id)
        user.delete()
        return redirect('admin_app:admin_home')
    

    